package demo;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.custommonkey.xmlunit.DetailedDiff;
import org.custommonkey.xmlunit.Diff;
import org.custommonkey.xmlunit.Difference;
import org.custommonkey.xmlunit.XMLUnit;
import org.xml.sax.SAXException;

// This example shows how to delete all CDs priced above 0
public class ComparisonTest {

public static void main(String[] args) {
	FileReader fr1 = null;
	FileReader fr2 = null;
	try {
	    fr1 = new FileReader("./src/test/java/com/qa/testdataxml/Raw2.xml");
	    fr2 = new FileReader("./src/test/java/com/qa/testdataxml/Converted2.xml");
	} catch (FileNotFoundException e) {
	    e.printStackTrace();	
    }
	
	XMLUnit.setNormalizeWhitespace(Boolean.FALSE);

    try {
        Diff diff = new Diff(fr1, fr2);
        System.out.println("Similar? " + diff.similar());
        System.out.println("Identical? " + diff.identical());

        DetailedDiff detDiff = new DetailedDiff(diff);
        List differences = detDiff.getAllDifferences();
        for (Object object : differences) {
            Difference difference = (Difference)object;
          //  System.out.println("***********************");
            System.out.println(difference);
           // System.out.println("***********************");
        }

    } catch (SAXException e) {
        e.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    }
}

}

    
