package demo;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.Node;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import com.ximpleware.AutoPilot;
import com.ximpleware.NavException;
import com.ximpleware.VTDGen;
import com.ximpleware.VTDNav;
import com.ximpleware.XPathEvalException;
import com.ximpleware.XPathParseException;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.ximpleware.AutoPilot;
import com.ximpleware.FastLongBuffer;
import com.ximpleware.VTDGen;
import com.ximpleware.VTDNav;
 
public class RemoveAttributeFromDOMElement {
     
    public static void main11(String[] args) throws Exception {
    	//String input="C:/Users/chauhaa8/Desktop/xmls/wookbook1.xml";
    	//String Output2="C:/Users/chauhaa8/Desktop/xmls/wookbook2.xml";
    	//String Output3="C:/Users/chauhaa8/Desktop/xmls/wookbook3.xml";
    	//String Xpath="/CATALOG/CD3";
    	
    	String input="./src/test/java/com/qa/testdataxml/Converted.xml";
    	String Output2="./src/test/java/com/qa/testdataxml/Converted2.xml";
    	String Output3="./src/test/java/com/qa/testdataxml/Converted3.xml";
    	String Xpath="//tr:pub-pt[1]/tr:ch[1]/tr:secmain[1]/core:para[2]/core:emph[1]";	
    	
    	try{
            VTDGen vg = new VTDGen();
            File fo = new File(Output2);
            FileOutputStream fos = new FileOutputStream(fo);
            if (vg.parseFile(input,false)){
                VTDNav vn = vg.getNav();
                
                AutoPilot ap = new AutoPilot(vn);
                ap.declareXPathNameSpace("tr", "http://www.lexisnexis.com/namespace/sslrp/tr/");
                ap.declareXPathNameSpace("core", "http://www.lexisnexis.com/namespace/sslrp/core/");
                ap.selectXPath(Xpath);
                // flb contains all the offset and length of the segments to be     skipped
                FastLongBuffer flb = new FastLongBuffer(4); // Page size is 2^4     = 16
                int i;
                byte[] xml = vn.getXML().getBytes();
                while( (i=ap.evalXPath())!= -1){             
                	flb.append(vn.getElementFragment());                         
                   
                }
                int size = flb.size();
                if (size == 0){
                    fos.write(xml); // No change needed because no CD is above    0
                }
                else{
                   int os1 = 0;
                   for (int k = 0;k<size; k++){
                       fos.write(xml, os1, flb.lower32At(k)-1 - os1);
                       os1 = flb.upper32At(k) + flb.lower32At(k);
                   }
                   fos.write(xml, os1, xml.length - os1);
               }
                Splitdata(input, Output3, Xpath);
                System.out.println("Files are updated");
            }
        }
        catch (Exception e){
            System.out.println("exception occurred ==>"+e);
        }
      }
public static void main(String[] args) throws Exception {
	String input="./src/test/java/com/qa/testdataxml/Converted.xml";
	String Output2="./src/test/java/com/qa/testdataxml/Converted2.xml";
	String Output3="./src/test/java/com/qa/testdataxml/Converted3.xml";
	String Xpath="//tr:pub-pt[1]/tr:ch[1]/tr:secmain[1]/core:para[2]";	


//public static void XmlDataSetUp(String input,String output2,String output3,String Xpath) throws Exception {
//	replacexmlSir.fileRemoveTag(input, Output2,Xpath);
	Splitdata(input,Output3,Xpath);
	
}    
    public static void Splitdata(String input,String output3,String xpath) {	
    	try{
            VTDGen vg = new VTDGen();
            if (vg.parseFile(input,false)){
                VTDNav vn = vg.getNav();
                AutoPilot ap = new AutoPilot(vn);
                ap.declareXPathNameSpace("tr", "http://www.lexisnexis.com/namespace/sslrp/tr/");
                ap.declareXPathNameSpace("core", "http://www.lexisnexis.com/namespace/sslrp/core/");
                ap.selectXPath(xpath); 
              //  ap.declareXPathNameSpace("xmlns:core", "http://www.lexisnexis.com/namespace/sslrp/core");

                // flb contains all the offset and length of the segments to be skipped
                FastLongBuffer flb = new FastLongBuffer(4);
                int i;
                byte[] xml = vn.getXML().getBytes();
                while( (i=ap.evalXPath())!= -1){
                    flb.append(vn.getElementFragment());
                }
                int size = flb.size();
                if (size != 0){
                    for (int k = 0;k<size; k++){
                        File fo = new File(output3);
                        FileOutputStream fos = new FileOutputStream(fo);
                        fos.write(xml, flb.lower32At(k), flb.upper32At(k));
                        fos.close();
                    }
                }
            }
        }
        catch (Exception e){
           // System.out.println("exception occurred ==>"+e);
        e.printStackTrace();
        }
    }

 }