package demo;

import java.io.File;

import java.io.FileInputStream;

import java.io.InputStreamReader;

import java.io.StringReader;

import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;

import javax.xml.parsers.DocumentBuilderFactory;

import javax.xml.transform.OutputKeys;

import javax.xml.transform.Result;

import javax.xml.transform.Source;

import javax.xml.transform.Transformer;

import javax.xml.transform.TransformerFactory;

import javax.xml.transform.dom.DOMSource;

import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;

import org.w3c.dom.Element;

import org.w3c.dom.Node;

import org.w3c.dom.NodeList;

import org.xml.sax.InputSource;

import pageObjects.TestMain;

public class replacexmlSir {

	public static void main(String[] args) throws Exception {

	
	//	public static void fileRemoveTag(String file1,String outPutFile2,String Xpath) throws Exception {
		String file1 = "./src/test/java/com/qa/testdataxml/Converted.xml";
		String outPutFile2="./src/test/java/com/qa/testdataxml/Converted2.xml";
		String saveRemaingNodeFile2="C:/Users/chauhaa8/Desktop/xmls/wookbook3.xml";
		
		File xmlf1 = new File(file1);

		String xmlfile1 = replacexmlSir.formatxml(xmlf1);

		DocumentBuilder builder1 = DocumentBuilderFactory.newInstance().newDocumentBuilder();

		InputSource src1 = new InputSource();

		src1.setCharacterStream(new StringReader(xmlfile1));

		Document doc = builder1.parse(src1);

		Element table = doc.getDocumentElement();

		
		Node row3 = table.getElementsByTagName("core:para").item(0);
		
		//Node row3 = table.getElementsByTagName("title").item(0);
		NodeList ndlist = row3.getChildNodes();
		int val = ndlist.getLength();
		table.removeChild(row3);
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer t = tf.newTransformer();
		t.transform(new DOMSource(doc), new StreamResult(System.out));
		t.transform(new DOMSource(doc), new StreamResult(new File(outPutFile2)));
	//	table.removeChild(row3);
		

	//	TransformerFactory tf = TransformerFactory.newInstance();

	//	Transformer t = tf.newTransformer();

		//t.transform(new DOMSource(doc), new StreamResult(System.out));
		
	//	t.transform(new DOMSource(doc), new StreamResult(new File(outPutFile2)));

		

	}

	public static String formatxml(File path) throws Exception {

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

		DocumentBuilder builder = factory.newDocumentBuilder();

		Document document = builder.parse(new InputSource(new InputStreamReader(new FileInputStream(path))));

		Transformer transformer = TransformerFactory.newInstance().newTransformer();

		transformer.setOutputProperty(OutputKeys.METHOD, "xml");

		transformer.setOutputProperty(OutputKeys.INDENT, "yes");

		transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");

		StringWriter writer = new StringWriter();

		transformer.transform(new DOMSource(document), new StreamResult(writer));

		String output = writer.getBuffer().toString(); // .replaceAll("\n|\r", "");

		output = output.replaceAll("[\r\n\t]+", " ");

		output = output.replaceAll("\\s+", " ");

		output = output.replaceAll(" +", " ");

	//	 output = TestMain.normalizeString(output);

		return output;

	}

}
