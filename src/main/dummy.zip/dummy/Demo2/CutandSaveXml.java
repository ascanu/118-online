package Demo2;

import com.ximpleware.*;
import java.io.*;
// This example shows how to delete all CDs priced above 0
public class CutandSaveXml {
	public static void main1(String[] args) {

		String input = "./src/test/java/com/qa/testdataxml/Converted.xml";
		String output = "./src/test/java/com/qa/testdataxml/Converted2.xml";
		String output2 = "./src/test/java/com/qa/testdataxml/Converted3.xml";
		String xpath = "//tr:pub";
	//	cut(input, output, xpath);
		paste(input,output2);
	}

	public static void cut(String input, String output, String xpath) {
		try {
			VTDGen vg = new VTDGen();
			File fo = new File(output);
			FileOutputStream fos = new FileOutputStream(fo);
			if (vg.parseFile(input, false)) {
				VTDNav vn = vg.getNav();
				AutoPilot ap = new AutoPilot(vn);
				ap.selectXPath("/CATALOG/CD3");
				// flb contains all the offset and length of the segments to be skipped
				FastLongBuffer flb = new FastLongBuffer(4); // Page size is 2^4 = 16
				int i;
				byte[] xml = vn.getXML().getBytes();
				while ((i = ap.evalXPath()) != -1) {
					flb.append(vn.getElementFragment());
				}
				int size = flb.size();
				System.out.println("Size of FLB :" + size);
				if (size == 0) {
					fos.write(xml); // No change needed because no CD is above 0
				} else {
					int os1 = 0;
					for (int k = 0; k < size; k++) {
						fos.write(xml, os1, flb.lower32At(k) - 1 - os1);
						os1 = flb.upper32At(k) + flb.lower32At(k);
					}
					fos.write(xml, os1, xml.length - os1);
					System.out.println("Files are written");
				}
			}
		} catch (Exception e) {
			System.out.println("exception occurred ==>" + e);
		}
	}

	public static void paste(String input, String output) {
	 	        try{
		            VTDGen vg = new VTDGen();
		            File fo = new File(output);
		            FileOutputStream fos = new FileOutputStream(fo);
		            if (vg.parseFile(input,false)){
		                VTDNav vn = vg.getNav();
		                AutoPilot ap = new AutoPilot(vn);
		                ap.selectXPath("/CATALOG/CD3");
		                // flb contains all the offset and length of the segments to be skipped
		                FastLongBuffer flb = new FastLongBuffer(4);
		                int i;
		                byte[] xml = vn.getXML().getBytes();
		                while( (i=ap.evalXPath())!= -1){
		                    flb.append(vn.getElementFragment());
		                }
		                VTDNav vn2 = null;
		                if (vg.parseFile(output,false)){
		                    vn2 = vg.getNav();
		                    AutoPilot ap2 = new AutoPilot(vn2);
		                    ap2.selectXPath("/CATALOG");
		                    byte[] xml2 = vn2.getXML().getBytes();
		                    long l2 = 0;
		                    if (ap2.evalXPath()!=-1){ // eval XPath just once
		                        l2 = vn2.getElementFragment();
		                    }
		                    int os = (int) l2;
		                    int len = (int) (l2>>32);
		                    int size = flb.size();
		                    if (size ==0) {
		                        fos.write(xml2);
		                    } else {
		                        fos.write(xml2, 0, os + len+1 );
		                        for (int k=0;k<size;k++){
		                            fos.write("\n".getBytes());
		                            fos.write(xml, flb.lower32At(k), flb.upper32At(k));
		                        }
		                        fos.write(xml2, os+len, xml2.length - (os+len+1));
		                    }
		                    fos.close();
		                }
		            }
		        }
		        catch (Exception e){
		            System.out.println("exception occurred ==>"+e);
		        }
		
  }
	
	
	public static void main(String[] args){
        try{
        	String input = "./src/test/java/com/qa/testdataxml/Converted.xml";    		
    		String output2 = "./src/test/java/com/qa/testdataxml/Converted2.xml";
    		String xpath1="//tr:pub-pt[1]/tr:ch[1]/tr:secmain[1]/core:para[2]";
    		
            String xpath="//tr:pub-pt[1]/tr:ch[1]/tr:secmain[1]/core:para[1]/core:emph[1]";
    		
    		String xmlContent = readFile(input);
    		
    		//System.out.println("XML Content : " + xmlContent);
    		
            VTDGen vg = new VTDGen();
            vg.setDoc(xmlContent.getBytes("UTF-8"));
         
            vg.parse(false);
            
            
                VTDNav vn = vg.getNav();
                AutoPilot ap = new AutoPilot(vn);
               
                ap.declareXPathNameSpace("tr", "http://www.lexisnexis.com/namespace/sslrp/tr/");
                ap.declareXPathNameSpace("core", "http://www.lexisnexis.com/namespace/sslrp/core/");
                ap.selectXPath(xpath);
                // flb contains all the offset and length of the segments to be skipped
                FastLongBuffer flb = new FastLongBuffer(4);
                int i;
                
          
                byte[] xml = vn.getXML().getBytes();
                
                while( (i=ap.evalXPath())!= -1){
                    flb.append(vn.getElementFragment());
                }
                int size = flb.size();
                if (size != 0){
                    for (int k = 0;k<size; k++){
                        File fo = new File(output2);
                        FileOutputStream fos = new FileOutputStream(fo);
                        fos.write(xml, flb.lower32At(k), flb.upper32At(k));
                        fos.close();
                        System.out.println("Passed");
                    }
                }
            //}
        }
        catch (Exception e){
         e.printStackTrace();
        	System.out.println("exception occurred ==>"+e);
        }
    }
	
	
	public static String readFile(String fileName) {
		StringBuilder strBuilder = new StringBuilder();
		try {
			File fileDir = new File(fileName);

			BufferedReader in = new BufferedReader(
			   new InputStreamReader(
	                      new FileInputStream(fileDir), "UTF8"));

			String str;
			
			while ((str = in.readLine()) != null) {
			    strBuilder.append(str);
			}

	                in.close();
		    }
		    catch (UnsupportedEncodingException e)
		    {
				System.out.println(e.getMessage());
		    }
		    catch (IOException e)
		    {
				System.out.println(e.getMessage());
		    }
		    catch (Exception e)
		    {
				System.out.println(e.getMessage());
		    }
		return strBuilder.toString();
	}
		
}