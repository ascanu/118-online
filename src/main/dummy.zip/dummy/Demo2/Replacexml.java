package Demo2;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;




public class Replacexml {
	
	//public static void main(String[] args) throws Exception {
				
		public static void replaceAndCutXml(String file1,String outPutFile2, String xmlcutdata, String TagName, Integer TagNameValue) throws Exception{
		//	String file1 = "./src/test/java/com/qa/testdataxml/Converted.xml";
		//	String xmlcutdata="./src/test/java/com/qa/testdataxml/xmlCutData.txt";			
		//		String outPutFile2="./src/test/java/com/qa/testdataxml/Converted2.xml";
			//	String TagName="core-para";
			//	Integer TagNameValue=2;
			
			File xmlf1 = new File(file1);
			String xmlfile1 = Replacexml.formatxml(xmlf1);
			DocumentBuilder builder1 = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			InputSource src1 = new InputSource();
			src1.setCharacterStream(new StringReader(xmlfile1));
			Document doc = builder1.parse(src1);
			Element table = doc.getDocumentElement();
		//	Node row3 = table.getElementsByTagName("core:para").item(0);
			Node categories = doc.getElementsByTagName("core:para").item(2);
			NodeList categorieslist = categories.getChildNodes();
			String text = null;
			List<String> cutXmlData = new ArrayList<String>();
			while (categorieslist.getLength() > 0) {
			    Node node = categorieslist.item(0);
			//    System.out.println(nodeToString(node));
			    text= nodeToString(node.getParentNode());	
			    cutXmlData.add(text);
			    System.out.println(text);
			    node.getParentNode().removeChild(node);	   
			}
			
			FileWriter writer = new FileWriter(xmlcutdata); 
			for(String str: cutXmlData) {			
				writer.write(str + System.lineSeparator());				
			}
			writer.close();
			
			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer t = tf.newTransformer();
			t.transform(new DOMSource(doc), new StreamResult(new File(outPutFile2)));
	}
	
	public static String formatxml(File path) throws Exception {

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

		DocumentBuilder builder = factory.newDocumentBuilder();

		Document document = builder.parse(new InputSource(new InputStreamReader(new FileInputStream(path))));

		Transformer transformer = TransformerFactory.newInstance().newTransformer();

		transformer.setOutputProperty(OutputKeys.METHOD, "xml");

		transformer.setOutputProperty(OutputKeys.INDENT, "yes");

		transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");

		StringWriter writer = new StringWriter();

		transformer.transform(new DOMSource(document), new StreamResult(writer));

		String output = writer.getBuffer().toString(); // .replaceAll("\n|\r", "");

		output = output.replaceAll("[\r\n\t]+", " ");

		output = output.replaceAll("\\s+", " ");

		output = output.replaceAll(" +", " ");

	//	 output = TestMain.normalizeString(output);

		return output;

	}
	private static String nodeToString(Node node) throws Exception, TransformerFactoryConfigurationError {
			StringWriter sw = new StringWriter();
		    Transformer t = TransformerFactory.newInstance().newTransformer();
		    t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
		    t.setOutputProperty(OutputKeys.INDENT, "yes");
		    t.transform(new DOMSource(node), new StreamResult(sw));
		    String output = sw.getBuffer().toString();
			output = output.replaceAll("[\r\n\t]+", " ");
			output = output.replaceAll("\\s+", " ");
			output = output.replaceAll(" +", " ");
			output = output.replaceAll("xml version=\"1.0\" encoding=\"UTF-8\"", " ");
			output = output.replaceAll("\\<core:para/>", "");
			
			return output;
		}	
	public static void stringToDom(String xmlSource, String outputFile) throws Exception {	    // Parse the given input
	    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	    DocumentBuilder builder = factory.newDocumentBuilder();
	    Document doc = builder.parse(new InputSource(new StringReader(xmlSource)));

	    // Write the parsed document to an xml file
	    TransformerFactory transformerFactory = TransformerFactory.newInstance();
	    Transformer transformer = transformerFactory.newTransformer();
	    DOMSource source = new DOMSource(doc);

	    StreamResult result =  new StreamResult(new File(outputFile));
	    transformer.transform(source, result);
	}
	
	
	public static void formatedxml(String input,String output ) throws Exception {		
		File xmlf2 = new File(input);	
		String xmlfile2 = Replacexml.formatxml(xmlf2);		
		Replacexml.stringToDom(xmlfile2, output);			
	}

}
